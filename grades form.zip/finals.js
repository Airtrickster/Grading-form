function reset() {
    document.getElementById("form").reset();
  }
  
  function compute() {
    var quiz1 = parseInt(document.getElementById("qz1").value);
    var quiz2 = parseInt(document.getElementById("qz2").value);
    var quiz3 = parseInt(document.getElementById("qz3").value);
    var act1 = parseInt(document.getElementById("lab1").value);
    var act2 = parseInt(document.getElementById("lab2").value);
    var act3 = parseInt(document.getElementById("lab3").value);
    var ass1 = parseInt(document.getElementById("as1").value);
    var ass2 = parseInt(document.getElementById("as2").value);
    var exam1 = parseInt(document.getElementById("exam").value);
  
    if (
      quiz1 > 100 ||
      quiz2 > 100 ||
      quiz3 > 100 ||
      act1 > 100 ||
      act2 > 100 ||
      act3 > 100 ||
      ass1 > 100 ||
      ass2 > 100 ||
      exam1 > 100
    ) {
      alert("Only range of 100");
    } else {
      var quizs = quiz1 + quiz2 + quiz3;
      var labs = act1 + act2 + act3;
      var hw = ass1 + ass2;
      var stand = (quizs / 300) * 60 + (labs / 300) * 20 + (hw / 200) * 20;
      var finals = (50 / 100) * stand + (50 / 100) * exam1;
      var fin = (1 / 3) * localStorage.getItem("mid") + (2 / 3) * finals;
      document.getElementById("prelim").innerHTML =
        "Your Prelim Grade is: " + localStorage.getItem("pre");
      document.getElementById("midterm").innerHTML =
        "Your Midterm Grade is: " + localStorage.getItem("pre");
      document.getElementById("final").innerHTML =
        "Your Finals Grade is: " + fin.toFixed(2);
    }
  }